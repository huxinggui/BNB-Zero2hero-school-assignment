import { readAddressList, storeAddressList } from "../scripts/addressRecord";
import {DeployFunction } from "hardhat-deploy/dist/types";
import {HardhatRuntimeEnvironment} from 'hardhat/types';

const func: DeployFunction = async function (hre: HardhatRuntimeEnvironment) {
  const { deployments, getNamedAccounts, network } = hre;
  const { deploy } = deployments;
  const { deployer } = await getNamedAccounts();
  console.log("Deploying ProxyAdmin with account:", deployer);
  const addressList:any=readAddressList();
  if(!addressList[network.name])
  {
    addressList[network.name] = {}
  };
  
  const proxyAdminContract = await deploy("ProxyAdmin", {
    contract: "ProxyAdmin",
    from: deployer,
    args: [],
    log: true
  });
  console.log(`ProxyAdmin Contract deployed to: ${proxyAdminContract.address}`);
  addressList[network.name].ProxyAdmin = proxyAdminContract.address;
  storeAddressList(addressList);
}
func.tags = ["ProxyAdmin"];
export default func;