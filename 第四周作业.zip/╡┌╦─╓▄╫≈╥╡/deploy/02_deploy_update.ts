import { readAddressList, storeAddressList } from "../scripts/addressRecord";
import {DeployFunction, ProxyOptions } from "hardhat-deploy/dist/types";
import {HardhatRuntimeEnvironment} from 'hardhat/types';
import { TransparentUpgradeableProxy__factory, ProxyAdmin__factory } from "../typechain-types";
const { ethers } = require("hardhat");
const func: DeployFunction = async function (hre: HardhatRuntimeEnvironment) {
  const { deployments, getNamedAccounts, network } = hre;
  const { deploy } = deployments;
  const { deployer } = await getNamedAccounts();
  console.log("Deploying My Contract with account:", deployer);
  const addressList:any=readAddressList();
  if(!addressList[network.name])
  {
    addressList[network.name] = {}
  };

  const myNewContract = await deploy(
    "ZriV2",
    {
      contract: "ZriV2",
      from: deployer,
      args: [],
      log: true
  });
  console.log(`myNewContract deployed to: ${myNewContract.address}`);
  addressList[network.name].Implementation_ZriV2 = myNewContract.address;
  storeAddressList(addressList);


  const [dev] = await ethers.getSigners();
  const proxyAddress = addressList[network.name].MyContract;
  const proxyAdminAddress = addressList[network.name].ProxyAdmin;

  const proxy = new TransparentUpgradeableProxy__factory(dev).attach(proxyAddress);
  const proxyAdmin = new ProxyAdmin__factory(dev).attach(proxyAdminAddress);
  
  const upgradeTx = await proxyAdmin.upgrade(proxy.address, myNewContract.address) ;
  console.log("MyContract upgraded to proxy");
  console.log("upgradeTx",upgradeTx);
}
func.tags = ["UpgradeContract"];
export default func;