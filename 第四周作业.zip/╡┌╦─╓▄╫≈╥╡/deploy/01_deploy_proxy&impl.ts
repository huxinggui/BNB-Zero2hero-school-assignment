import { readAddressList, storeAddressList } from "../scripts/addressRecord";
import {DeployFunction, ProxyOptions } from "hardhat-deploy/dist/types";
import {HardhatRuntimeEnvironment} from 'hardhat/types';

const func: DeployFunction = async function (hre: HardhatRuntimeEnvironment) {
  const { deployments, getNamedAccounts, network } = hre;
  const { deploy } = deployments;
  const { deployer } = await getNamedAccounts();
  console.log("Deploying My Contract with account:", deployer);
  const addressList:any=readAddressList();
  if(!addressList[network.name])
  {
    addressList[network.name] = {}
  };

  const proxyOptions: ProxyOptions = {
    proxyContract: "TransparentUpgradeableProxy",//库标准合约
    viaAdminContract: "ProxyAdmin",
    execute: {
      init: {
        // 执行initialize方法
        methodName: "init",
        // 参数
        args: [50]
      },
    },
  };

  const myContract = await deploy("Zri", {
    contract: "Zri",
    from: deployer,
    proxy: proxyOptions,
    args: [],
    log: true,
  });
  console.log(`Proxy deployed to: ${myContract.address}`);
  console.log(`Implementation deployed to: ${myContract.implementation}`);
  addressList[network.name].MyContract = myContract.address;
  addressList[network.name].Implementation_Zri = myContract.implementation;
  storeAddressList(addressList);
}

func.tags = ["MyContract"];
export default func;