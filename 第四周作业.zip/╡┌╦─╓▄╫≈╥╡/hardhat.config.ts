import { HardhatUserConfig  } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";
import "hardhat-deploy";

import "./tasks"
import "./tasks/index"

require("dotenv").config({ path: 'secret.env' });
const mnemonic = process.env.mnemonic;
const goerli_url = process.env.goerli_url;
const bsc_url = process.env.bsc_url;
const bsctest_url = process.env.bsctest_url;
const private_key = process.env.private_key as string;
const etherscan_api_key = process.env.etherscan_api_key;
const config: HardhatUserConfig = {
  solidity: {
    version:"0.8.18",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },
  namedAccounts: {
    deployer: {
      default: 0,
      localhost: 0,
      tokenOwner: 0,
    },
  },
  defaultNetwork: "localhost",
  networks: {
    localhost: {
      url: "http://localhost:8545",
      accounts:{
        mnemonic: mnemonic
      },
    },
    bsctest: {
      url: bsctest_url,
      accounts: [private_key],
      timeout: 100000
    },
    goerli: {
      url: goerli_url,
      chainId: 5,
      accounts: [private_key]
    },
    bsc: {
      url: bsc_url,
      chainId: 56,
      accounts: [private_key]
    }
  },
  paths: {
    sources: "./contracts",
    tests: "./test",
    cache: "./cache",
    artifacts: "./artifacts",
  },  
  mocha: {
    timeout: 600000,
  }
};

export default config;

